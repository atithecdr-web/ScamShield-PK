# 🛡️ ScamShield PK — powered by DhokaNet

**DhokaNet** ("dhoka" = fraud in Urdu) is a lightweight AI model that detects scam and phishing
SMS/WhatsApp messages written in **English and Roman Urdu**, and explains *why* a message is risky.

## Problem
Fake Easypaisa/JazzCash alerts, fake BISP/Ehsaas payments, prize scams and OTP theft hit millions of
Pakistanis. Most spam filters only understand English and give no explanation.

## Solution
1. **ML model** – character n-gram TF-IDF + Logistic Regression. Character n-grams handle
   inconsistent Roman Urdu spelling (foran / furan / fori).
2. **Explainable red-flag engine** – detects links, urgency, requests for OTP/PIN/CNIC, fake prizes,
   brand impersonation, "send money back" tricks.
3. **Risk score** (0–100) = 75% model + 25% red flags → SAFE / SUSPICIOUS / SCAM.
4. **Streamlit web app** for live demo. Runs fully offline, no API key.

## Files
| File | Purpose |
|---|---|
| `data.py` | Bilingual dataset + augmentation |
| `train.py` | Trains DhokaNet, prints metrics, saves `dhokanet.joblib` |
| `scamshield.py` | Inference + red-flag rules (also usable from CLI) |
| `app.py` | Streamlit web UI |
| `requirements.txt` | Dependencies |

## Run
```bash
pip install -r requirements.txt
python train.py
streamlit run app.py
# or CLI:
python scamshield.py "Aapka account band ho jaye ga, OTP bataein"
```

## Demo script (60 seconds)
1. Paste the fake Easypaisa message → 🔴 SCAM with reasons.
2. Paste a normal friend message → 🟢 SAFE.
3. Mention: works offline, bilingual, explainable.

## Future work
- Train on a large real SMS dataset and add Urdu script (اردو) support
- WhatsApp/Telegram bot and Android SMS-filter app
- Fine-tune a multilingual transformer (XLM-R) for higher accuracy
- Community reporting of scam numbers/links

## Limitations
The bundled dataset is small (demo-scale). Add more real examples for production accuracy.
