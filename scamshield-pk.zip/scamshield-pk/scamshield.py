"""DhokaNet inference: ML probability + explainable red-flag rules."""
import re
import joblib

_model = None

FLAGS = {
    "Contains a link (often fake/phishing)": r"https?://|www\.|bit\.ly|\.xyz|\.top|\.cc\b|tinyurl",
    "Creates urgency / threatens blocking": r"urgent|immediately|final warning|24 hours|block|suspend|tonight|foran|abhi|band ho|aaj raat|ghantay",
    "Asks for sensitive info (OTP/PIN/CNIC/card)": r"\botp\b|\bpin\b|cnic|password|card (number|details)|6 digit|code you",
    "Promises prizes or easy money": r"you have won|won rs|lucky draw|inaam|lakh|double your money|munafa|profit|earn rs|kamayein|wazifa|eligible",
    "Impersonates an official brand": r"easypaisa|jazzcash|bisp|ehsaas|customs|bank se|support|nadra|sim will",
    "Asks to send money back / pay a fee": r"send (it )?back|wapas bhej|pay rs|fee|jama karwayein",
}


def _load():
    global _model
    if _model is None:
        _model = joblib.load("dhokanet.joblib")
    return _model


def analyze(text: str) -> dict:
    p = float(_load().predict_proba([text])[0][1])
    reasons = [name for name, rx in FLAGS.items() if re.search(rx, text, re.I)]
    score = 0.75 * p + 0.25 * min(len(reasons) / 3, 1.0)
    verdict = "SCAM" if score >= 0.65 else "SUSPICIOUS" if score >= 0.4 else "SAFE"
    return {"verdict": verdict, "risk": round(score * 100), "ml_probability": round(p, 3), "reasons": reasons}


if __name__ == "__main__":
    import sys
    msg = " ".join(sys.argv[1:]) or input("Paste a message: ")
    r = analyze(msg)
    print(f"{r['verdict']}  (risk {r['risk']}%)")
    for x in r["reasons"]:
        print(" -", x)
