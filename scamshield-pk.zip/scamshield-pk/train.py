"""Train DhokaNet: char n-gram TF-IDF + Logistic Regression.
Char n-grams handle Roman Urdu spelling variations (foran/furan, inaam/inam)."""
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from data import augment, base_data

texts, labels = base_data()
# split BEFORE augmenting so test messages are never seen in training
X_tr, X_te, y_tr, y_te = train_test_split(
    texts, labels, test_size=0.25, stratify=labels, random_state=7
)
X_tr, y_tr = augment(X_tr, y_tr)

model = Pipeline([
    ("tfidf", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), lowercase=True, sublinear_tf=True)),
    ("clf", LogisticRegression(C=5.0, max_iter=1000, class_weight="balanced")),
])
model.fit(X_tr, y_tr)

print(classification_report(y_te, model.predict(X_te), target_names=["safe", "scam"]))

# final model: train on everything
all_t, all_y = augment(texts, labels)
model.fit(all_t, all_y)
joblib.dump(model, "dhokanet.joblib")
print("Saved dhokanet.joblib")
