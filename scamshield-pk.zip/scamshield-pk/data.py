"""Small bilingual (English + Roman Urdu) dataset for DhokaNet.
Replace/extend these lists with real messages to improve accuracy."""
import random

SCAM = [
    "Congratulations! You have won Rs 500,000 in the Jazz lucky draw. Send your CNIC and card details to claim now.",
    "Your Easypaisa account will be blocked in 24 hours. Click http://easypaisa-verify.xyz to verify now.",
    "Dear customer, your bank account is suspended. Share your OTP to reactivate immediately.",
    "BISP: You are eligible for Rs 25000 Ehsaas payment. Register at bit.ly/ehsaas-claim today.",
    "Your parcel is held at customs. Pay Rs 300 fee at http://track-parcel.top to release it.",
    "Earn Rs 5000 daily from home! No experience needed. WhatsApp us now to join.",
    "We are from JazzCash support. Please tell us the 6 digit code you just received.",
    "Your SIM will be blocked today. Verify biometric by clicking this link.",
    "Final warning: your electricity bill is overdue. Pay now at http://pay-bill.cc or power will be cut tonight.",
    "You have received Rs 10,000 by mistake. Please send it back to this number urgently.",
    "Limited offer! Double your money in 1 hour. Invest now and get 100% profit guaranteed.",
    "Your ATM card is expired. Update PIN and card number at the link to avoid closure.",
    "Mubarak ho! Aap ne 10 lakh ka inaam jeeta hai. Apna CNIC aur account number foran bhejein.",
    "Aapka Easypaisa account 24 ghantay mein band ho jaye ga. Abhi is link par click karein.",
    "Mehrbani karke apna OTP code humein bata dein warna aapka account block ho jaye ga.",
    "Ehsaas program mein aap ka 25000 ka wazifa aaya hai. Is link se register karein.",
    "Ghar baithe roz 5000 kamayein. Abhi WhatsApp karein, koi tajurba zaroori nahi.",
    "Main bank se bol raha hoon, aap ka card block hone wala hai, apna PIN batayen.",
    "Ghalti se aap ke number par 5000 rupay aa gaye hain, meherbani karke wapas bhej dein.",
    "Aap ki SIM aaj raat band ho jaye gi. Biometric verify karne ke liye link kholein.",
    "Paisay double karein sirf 1 ghantay mein, 100% munafa guarantee.",
    "Aap ka parcel custom mein ruka hua hai, fee jama karwayein warna wapas bhej diya jaye ga.",
]

SAFE = [
    "Hey, are we still meeting for lunch at 1 pm tomorrow?",
    "Your OTP for login is 483920. Do not share it with anyone.",
    "Meeting moved to 3 pm, please bring the project report.",
    "Thanks for your payment of Rs 1,500. Your receipt number is 88231.",
    "Happy birthday! Wishing you a great year ahead.",
    "Can you send me the notes from today's lecture?",
    "Your order has been shipped and will arrive on Thursday.",
    "Reminder: dentist appointment tomorrow at 5 pm.",
    "I'll call you after Maghrib, just reached home.",
    "The assignment deadline is extended to Friday midnight.",
    "Your monthly statement is ready. Log in to the official app to view it.",
    "Dinner is ready, come downstairs.",
    "Assalam o alaikum, kal shaam ko ghar aa rahe ho?",
    "Meeting 3 baje shift ho gayi hai, report le kar aana.",
    "Bhai notes bhej dena jo aaj class mein diye thay.",
    "Aap ka bill 2,450 rupay jama ho gaya hai, shukriya.",
    "Main raaste mein hoon, 10 minute mein pohanch jaunga.",
    "Eid Mubarak! Allah aap ko hamesha khush rakhe.",
    "Kal paper hai, aaj raat tak padhai kar lo.",
    "Ammi keh rahi hain dahi le aana wapas aate hue.",
    "Aap ka order kal tak deliver ho jaye ga.",
    "Hackathon ki team meeting kal subah 10 baje hai.",
    "Khana tayar hai, neechay aa jao.",
    "Doctor ki appointment parson 6 baje hai.",
]

_PREFIX = ["", "", "URGENT: ", "Dear customer, ", "Alert! ", "Salam, ", "Notice: "]
_SUFFIX = ["", "", " Thanks.", " Reply soon.", " Regards.", " Shukriya."]


def base_data():
    texts = SCAM + SAFE
    labels = [1] * len(SCAM) + [0] * len(SAFE)
    return texts, labels


def augment(texts, labels, n=6, seed=42):
    """Cheap augmentation: random prefix/suffix + casing noise."""
    rng = random.Random(seed)
    out_t, out_l = list(texts), list(labels)
    for t, y in zip(texts, labels):
        for _ in range(n):
            s = rng.choice(_PREFIX) + t + rng.choice(_SUFFIX)
            if rng.random() < 0.3:
                s = s.lower()
            out_t.append(s)
            out_l.append(y)
    return out_t, out_l
