import os
import streamlit as st
from scamshield import analyze

st.set_page_config(page_title="ScamShield PK", page_icon="🛡️")
st.title("🛡️ ScamShield PK")
st.caption("Powered by DhokaNet — scam detection for English & Roman Urdu messages")

if not os.path.exists("dhokanet.joblib"):
    st.error("Model not found. Run `python train.py` first.")
    st.stop()

examples = {
    "Fake Easypaisa": "Aapka Easypaisa account 24 ghantay mein band ho jaye ga. Abhi http://ep-verify.xyz par click karein.",
    "Fake prize": "Congratulations! You won Rs 500,000. Send CNIC and card details to claim.",
    "Normal message": "Bhai kal meeting 3 baje hai, notes le aana.",
}
choice = st.selectbox("Try an example", ["(write my own)"] + list(examples))
msg = st.text_area("Paste a message", value=examples.get(choice, ""), height=130)

if st.button("Check message", type="primary") and msg.strip():
    r = analyze(msg)
    color = {"SCAM": "🔴", "SUSPICIOUS": "🟠", "SAFE": "🟢"}[r["verdict"]]
    st.subheader(f"{color} {r['verdict']}")
    st.progress(r["risk"] / 100, text=f"Risk score: {r['risk']}%")
    if r["reasons"]:
        st.write("**Why:**")
        for x in r["reasons"]:
            st.write(f"- {x}")
    else:
        st.write("No red flags found.")
    st.info("Never share OTP, PIN or CNIC. Report scams to FIA Cybercrime (1991).")
